
<html>
<head>
   
</head>
<style>
 
 
</style>
 
<h1> Laravel  hasOneThrough Example </h1>
 
<h3> Order of Supplier one </h3>
 
<li> 
 
    {{ $supplier_one->order_name }}  
 
</li>

<h3> Order of Supplier two </h3>
 
<li> 
 
    {{ $supplier_two->order_name }}  
 
</li>


</html>