
<html>
<head>
   
</head>
<style>
 
 
</style>
 
<h1> Laravel  hasOneThrough Example </h1>
 
<h3> Order of Supplier one </h3>
 
<li> 
 
    <?php echo e($supplier_one->order_name); ?>  
 
</li>

<h3> Order of Supplier two </h3>
 
<li> 
 
    <?php echo e($supplier_two->order_name); ?>  
 
</li>


</html><?php /**PATH /Users/hardikparsania_mac/Desktop/web_demonuts/larahasone/larahasone/resources/views/index.blade.php ENDPATH**/ ?>